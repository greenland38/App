#!/usr/bin/env python3
"""Remplace le mot de passe administrateur temporaire de index.html.
Usage : python3 tools/set-admin-password.py "MonNouveauMotDePasse"
Le mot de passe temporaire livré est : ChangeMoi-2026  (à changer AVANT toute mise en ligne)."""
import sys, hashlib, pathlib
if len(sys.argv) != 2 or len(sys.argv[1]) < 10:
    sys.exit('Donnez un mot de passe de 10 caractères minimum.')
old = hashlib.sha256(b'ChangeMoi-2026').hexdigest()
new = hashlib.sha256(sys.argv[1].encode()).hexdigest()
p = pathlib.Path(__file__).resolve().parent.parent / 'index.html'
t = p.read_text(encoding='utf-8')
if old not in t: sys.exit('Hash temporaire introuvable : mot de passe déjà changé ?')
p.write_text(t.replace(old, new), encoding='utf-8'); print('Mot de passe administrateur mis à jour.')
