#!/usr/bin/env python3
"""Génère une paire de clés VAPID (notifications push) PROPRE à chaque commerce.
La clé publique va dans l'administration (ou la fonction), la clé privée uniquement dans les Secrets Supabase."""
import base64
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
b = lambda x: base64.urlsafe_b64encode(x).rstrip(b'=').decode()
k = ec.generate_private_key(ec.SECP256R1())
pub = k.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
d = k.private_numbers().private_value.to_bytes(32, 'big')
print('VAPID_PUBLIC_KEY =', b(pub)); print('VAPID_PRIVATE_KEY =', b(d))
print('HOOK_SECRET      =', b(__import__("os").urandom(24)))
