// Fonction Supabase « describe » : rédige les descriptions produits (réservée à l'administrateur).
// Utilise l'API gratuite de Groq. Secrets : GROQ_API_KEY (obligatoire), GROQ_MODEL (facultatif).
const SU = Deno.env.get("SUPABASE_URL")!;
const SK = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const AK = Deno.env.get("GROQ_API_KEY") || "";
const MODEL = Deno.env.get("GROQ_MODEL") || "llama-3.3-70b-versatile";
const FALLBACKS = ["llama-3.1-8b-instant"];
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const J = (o: unknown, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { ...CORS, "Content-Type": "application/json" } });

async function isAdmin(req: Request) {
  const t = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!t) return false;
  const r = await fetch(`${SU}/auth/v1/user`, { headers: { apikey: SK, Authorization: `Bearer ${t}` } });
  if (!r.ok) return false;
  const u = await r.json();
  if (!u?.id) return false;
  const p = await (await fetch(`${SU}/rest/v1/profiles?select=is_admin&id=eq.${u.id}`, {
    headers: { apikey: SK, Authorization: `Bearer ${SK}` },
  })).json();
  return !!p?.[0]?.is_admin;
}

const SYSTEM = [
  "Tu es rédacteur e-commerce pour une boutique en ligne francophone. Écris toujours en français.",
  "À partir du nom du produit et de 2 à 3 mots-clés, écris une description courte (3 à 5 phrases, 60 à 90 mots), vivante et enjouée, qui donne envie d'acheter.",
  "Termine par un appel à l'action (ex. Commandez-le dès maintenant). Place 3 à 6 emojis bien choisis, sans en abuser. Vouvoie le client.",
  "Règles : n'invente aucun fait (taux, origine, laboratoire, prix) absent des infos fournies ; aucune promesse de santé ou thérapeutique (soulage, soigne, traite…) ; aucune allégation d'effets ; produit réservé aux adultes.",
  "Réponds uniquement avec le texte de la description, sans titre ni guillemets.",
].join("\n");

const ask = (model: string, info: string) =>
  fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${AK}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      max_tokens: 400,
      temperature: 0.8,
      messages: [{ role: "system", content: SYSTEM }, { role: "user", content: info }],
    }),
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    if (!(await isAdmin(req))) return J({ ok: false, error: "Compte administrateur requis." }, 403);
    if (!AK) return J({ ok: false, error: "Secret GROQ_API_KEY manquant dans Supabase (Edge Functions → Secrets)." }, 500);
    const b = await req.json().catch(() => ({}));
    const cut = (v: unknown, n: number) => String(v || "").trim().slice(0, n);
    const info = [
      "Nom : " + cut(b.n, 120),
      "Mots-clés : " + cut(b.k, 200),
      b.c ? "Catégorie : " + cut(b.c, 60) : "",
      b.p ? "Prix : " + cut(b.p, 20) + " €" : "",
    ].filter(Boolean).join("\n");

    const models = Deno.env.get("GROQ_MODEL") ? [MODEL] : [MODEL, ...FALLBACKS];
    let r: Response | null = null;
    for (const m of models) {
      r = await ask(m, info);
      console.log("DESCRIBE groq model=" + m + " status=" + r.status);
      // 401/403 = clé refusée : inutile d'essayer un autre modèle
      if (r.ok || r.status === 401 || r.status === 403) break;
    }
    const j = await r!.json().catch(() => ({}));
    if (!r!.ok) {
      const msg = j?.error?.message || j?.message || "Erreur du service de rédaction.";
      console.error("DESCRIBE groq error status=" + r!.status + " body=" + JSON.stringify(j).slice(0, 400));
      return J({ ok: false, error: "Groq " + r!.status + " : " + (typeof msg === "string" ? msg : JSON.stringify(msg)), upstream: r!.status }, 502);
    }
    const text = String(j?.choices?.[0]?.message?.content || "").trim();
    return J({ ok: !!text, text });
  } catch (e) {
    console.error("DESCRIBE exception " + String((e as Error)?.message || e));
    return J({ ok: false, error: String((e as Error)?.message || e) }, 500);
  }
});
