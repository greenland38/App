-- À lancer UNE fois : Supabase > SQL Editor > New query > Run
alter table public.profiles add column if not exists id_status text not null default 'none';
alter table public.profiles add column if not exists id_path text;
alter table public.profiles add column if not exists id_sign text;
alter table public.profiles add column if not exists id_sign_at timestamptz;

create or replace function public.guard_id() returns trigger language plpgsql as $$
begin
  if (new.id_status is distinct from old.id_status or new.id_path is distinct from old.id_path
      or new.id_sign is distinct from old.id_sign or new.id_sign_at is distinct from old.id_sign_at)
     and coalesce(current_setting('app.idv', true), '') <> '1' then
    raise exception 'interdit';
  end if;
  return new;
end $$;
drop trigger if exists guard_id on public.profiles;
create trigger guard_id before update on public.profiles for each row execute function public.guard_id();

-- Signe aléatoire (geste + code à 4 chiffres), valable 60 minutes, généré par le serveur
create or replace function public.id_challenge() returns text
language plpgsql security definer set search_path = public, extensions as $$
declare
  uid uuid := auth.uid();
  g text[] := array[
    'pouce levé de la main droite', 'deux doigts en « V » de la main gauche', 'main droite ouverte à côté de la joue',
    'trois doigts levés de la main gauche', 'index droit posé sur le bout du nez', 'poing fermé devant le menton',
    'main gauche posée sur le sommet de la tête', 'les deux mains ouvertes de chaque côté du visage',
    'index gauche posé sur la joue', 'quatre doigts levés de la main droite'];
  code text; sign text;
begin
  if uid is null then raise exception 'Connexion requise.'; end if;
  code := lpad(((get_byte(gen_random_bytes(2), 0) * 256 + get_byte(gen_random_bytes(2), 1)) % 10000)::text, 4, '0');
  sign := g[1 + (get_byte(gen_random_bytes(1), 0) % array_length(g, 1))] || ' + feuille de papier avec le code ' || code;
  perform set_config('app.idv', '1', true);
  update public.profiles set id_sign = sign, id_sign_at = now() where id = uid;
  return sign;
end $$;
revoke all on function public.id_challenge() from public, anon;
grant execute on function public.id_challenge() to authenticated;

create or replace function public.set_id(p_uid uuid, p_status text, p_path text) returns void
language plpgsql security definer set search_path = public as $$
declare adm boolean; fresh boolean;
begin
  select is_admin into adm from public.profiles where id = auth.uid();
  if p_uid = auth.uid() and p_status = 'pending' and not coalesce(adm, false) then
    select (id_sign_at is not null and id_sign_at > now() - interval '60 minutes') into fresh from public.profiles where id = p_uid;
    if not coalesce(fresh, false) then raise exception 'signe expiré'; end if;
  elsif coalesce(adm, false) then null;
  else raise exception 'interdit'; end if;
  perform set_config('app.idv', '1', true);
  update public.profiles set id_status = p_status, id_path = p_path where id = p_uid;
end $$;
grant execute on function public.set_id(uuid, text, text) to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('ids', 'ids', false, 8388608, array['image/jpeg', 'image/png', 'image/webp'])
  on conflict (id) do update set file_size_limit = 8388608, allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];
drop policy if exists "ids_insert_own" on storage.objects;
create policy "ids_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'ids' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "ids_read" on storage.objects;
create policy "ids_read" on storage.objects for select to authenticated
  using (bucket_id = 'ids' and ((storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.profiles where id = auth.uid() and is_admin)));
drop policy if exists "ids_delete_admin" on storage.objects;
create policy "ids_delete_admin" on storage.objects for delete to authenticated
  using (bucket_id = 'ids' and exists (select 1 from public.profiles where id = auth.uid() and is_admin));