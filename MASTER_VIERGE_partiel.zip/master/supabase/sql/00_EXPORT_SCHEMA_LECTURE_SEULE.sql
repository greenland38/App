-- À lancer dans le SQL Editor de TON ANCIEN projet (lecture seule : uniquement des SELECT).
-- Il exporte la structure (aucune donnée client). ATTENTION : la section « cron » peut contenir
-- un secret : ne la partage pas telle quelle, remplace toute valeur secrète par XXX avant envoi.
select 'tables' as section, jsonb_agg(jsonb_build_object('t',table_name,'c',column_name,'type',data_type,'null',is_nullable,'def',column_default) order by table_name,ordinal_position) as data from information_schema.columns where table_schema='public'
union all select 'contraintes', jsonb_agg(jsonb_build_object('t',conrelid::regclass::text,'n',conname,'def',pg_get_constraintdef(oid))) from pg_constraint where connamespace='public'::regnamespace
union all select 'index', jsonb_agg(indexdef) from pg_indexes where schemaname='public'
union all select 'rls_actif', jsonb_agg(jsonb_build_object('t',relname,'rls',relrowsecurity)) from pg_class where relnamespace='public'::regnamespace and relkind='r'
union all select 'politiques', jsonb_agg(jsonb_build_object('s',schemaname,'t',tablename,'n',policyname,'cmd',cmd,'roles',roles,'using',qual,'check',with_check)) from pg_policies where schemaname in ('public','storage')
union all select 'fonctions', jsonb_agg(pg_get_functiondef(p.oid)) from pg_proc p where pronamespace='public'::regnamespace
union all select 'triggers', jsonb_agg(pg_get_triggerdef(oid)) from pg_trigger where not tgisinternal and tgrelid in (select oid from pg_class where relnamespace='public'::regnamespace)
union all select 'buckets', jsonb_agg(to_jsonb(b)) from storage.buckets b
union all select 'extensions', jsonb_agg(extname) from pg_extension
union all select 'cron', coalesce((select jsonb_agg(jsonb_build_object('name',jobname,'schedule',schedule,'cmd',command)) from cron.job),'[]'::jsonb);
