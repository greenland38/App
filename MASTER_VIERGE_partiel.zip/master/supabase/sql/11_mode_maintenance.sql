-- À lancer UNE fois : Supabase > SQL Editor > New query > Run
create table if not exists public.site_flags (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.site_flags enable row level security;
drop policy if exists sf_sel on public.site_flags;
create policy sf_sel on public.site_flags for select to anon, authenticated using (key in ('maint','maint_img'));
drop policy if exists sf_ins on public.site_flags;
create policy sf_ins on public.site_flags for insert to authenticated with check (exists (select 1 from public.profiles where id = auth.uid() and is_admin));
drop policy if exists sf_upd on public.site_flags;
create policy sf_upd on public.site_flags for update to authenticated using (exists (select 1 from public.profiles where id = auth.uid() and is_admin)) with check (exists (select 1 from public.profiles where id = auth.uid() and is_admin));
drop policy if exists sf_del on public.site_flags;
create policy sf_del on public.site_flags for delete to authenticated using (exists (select 1 from public.profiles where id = auth.uid() and is_admin));
grant select on public.site_flags to anon;
grant select, insert, update, delete on public.site_flags to authenticated;