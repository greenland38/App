-- À lancer UNE fois : Supabase > SQL Editor > New query > Run
alter table public.profiles add column if not exists pseudo text;
alter table public.profiles add column if not exists points integer not null default 0;
create unique index if not exists profiles_pseudo_uq on public.profiles (lower(pseudo)) where pseudo is not null;

create or replace function public.guard_pts() returns trigger language plpgsql as $$
begin
  if new.points is distinct from old.points and coalesce(current_setting('app.pts', true), '') <> '1' then
    raise exception 'interdit';
  end if;
  return new;
end $$;
drop trigger if exists guard_pts on public.profiles;
create trigger guard_pts before update on public.profiles for each row execute function public.guard_pts();

create or replace function public.add_points(p_uid uuid, p_delta integer) returns integer
language plpgsql security definer set search_path = public as $$
declare adm boolean; res integer;
begin
  select is_admin into adm from public.profiles where id = auth.uid();
  if not coalesce(adm, false) then raise exception 'interdit'; end if;
  perform set_config('app.pts', '1', true);
  update public.profiles set points = greatest(0, points + p_delta) where id = p_uid returning points into res;
  return res;
end $$;
grant execute on function public.add_points(uuid, integer) to authenticated;